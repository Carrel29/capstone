<?php
session_start();

include_once "../includes/dbh.inc.php";
require "../includes/bookingData.php";
include_once "../includes/allData.php";
include_once "../includes/dbh.inc.php";
include_once "../includes/userData.php";

$data = new AllData($pdo);
$getUserById = $data->getUserById($user_id);
$allBookingAndUser = $data->getBookingAndUserById($user_id);
$services = $data->getAllServices();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/style.css" />
    <script src="../JS/payment.js"></script>
    <script src="../JS/services.js"></script>
    <title>Booking Receipt</title>
</head>

<body>
    <header>
        <h1 class="company-name">BTONE</h1>
        <nav class="nav-bar">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#aboutus">About Us</a></li>
                <li class="dropdown">
                    <a href="#"><img src="../Img/menu.png" alt="" class="img-round"></a>
                    <ul class="dropdown-content">
                        <li><a href="#"><?php echo $fullname ?></a></li>
                        <li><a href="../includes/logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>

    <main class=" h-100 gap-20">
        <div>
            <h1 class="text-center">Booking form</h1>
        </div>
        <div class="card w-100">
            <div class="combo-display-flex-column-start w-100 mx-20">
                <form action="../includes/bookingData.php" method="POST" class="w-100">
                    <input type="hidden" name="btuser_id" value="<?php echo htmlspecialchars($user_id); ?>">
                    <div>
                        <label for="name">Name</label>
                        <input type="text" value="<?php echo htmlspecialchars($fullname); ?>" required>
                    </div>
                    <div>
                        <label for="address">Address</label>
                        <input type="text" name="btaddress" required>
                    </div>
                    <div>
                        <label for="contact">Contact No.</label>
                        <input type="text" value="<?php echo $getUserById['bt_phone_number']; ?>" required>
                    </div>
                    <div>
                        <label for="email">Email</label>
                        <input type="email" value="<?php echo htmlspecialchars($email); ?>" required>
                    </div>
                    <div>
                        <label for="event">Event</label>
                        <Select name="btevent" class="form-control" required>
                            <?php
                            $events = [
                                "Weddings",
                                "18 Birthday",
                                "Silver and Golden",
                                "60th Birthday & Anniversary",
                                "Children Party",
                                "Birthday Party",
                                "Christmas & Yearend Party",
                                "Exhibits",
                                "Seminar",
                                "Js Prom",
                                "Graduation Ball",
                                "Graduation"
                            ];

                            foreach ($events as $event) {
                                echo '<option value="' . htmlspecialchars($event) . '">' . htmlspecialchars($event) . '</option>';
                            }
                            ?>
                        </Select>
                    </div>
                    <div>
                        <label for="schedule">Schedule</label>
                        <input type="datetime-local" name="btschedule" required>
                    </div>
                    <div>
                        <label for="event duration">Event Duration</label>
                        <Select name="event_duration" id="event_duration" class="form-control" required>
                            <option value="12">Half Day (12 hours)</option>
                            <option value="24">Whole Day (24 hours)</option>
                        </Select>
                    </div>
                    <div>
                        <label for="Attendees">No. Attendees</label>
                        <input type="number" name="btattendees" require>
                    </div>
                    <label for="services">Services</label>
                    <div class="checkbox-group">
                        <?php foreach ($services as $service): ?>
                            <div class="checkbox-item">
                                <input type="checkbox" id="service-<?php echo htmlspecialchars($service['services_id']); ?>" name="btservices[]" value="<?php echo htmlspecialchars($service['name']); ?>">
                                <label for="service-<?php echo htmlspecialchars($service['services_id']); ?>"><?php echo htmlspecialchars($service['name']); ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <label for="Message">Message</label>
                    <input type="text" name="btmessage" required>
                    <div class="btn-group-card gap-20">
                        <input class="btn btn-view-now" type="submit" value="Submit">
                    </div>
                </form>
            </div>
        </div>
    </main>

</body>

</html>