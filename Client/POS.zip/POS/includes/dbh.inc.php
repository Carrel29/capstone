<?php
$serverName = "localhost";
$dBUsername = "btone";
$dBPassword = "Btone123@...";

$dsn = "mysql:host=$serverName;port=3308;dbname=btonedatabase";

try {
    $pdo = new PDO($dsn, $dBUsername, $dBPassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "ERROR: Could not connect. " . $e->getMessage();
}


if (!isset($_SESSION['last_regeneration'])) {
    $_SESSION['last_regeneration'] = time();
} elseif (time() - $_SESSION['last_regeneration'] > 600) {
    session_regenerate_id(true);
    $_SESSION['last_regeneration'] = time();
}