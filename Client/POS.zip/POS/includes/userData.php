<?php

$fullname = $_SESSION["fullname"]??"";
$email = $_SESSION["email"]??"";
$privilege = $_SESSION["privilege"]??"";
$user_id = $_SESSION["user_id"]??"";
