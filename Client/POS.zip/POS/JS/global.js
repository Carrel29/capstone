const noTextInput =  document.querySelector('#Phonenumber');

noTextInput.addEventListener('keypress', (e) => {
    if (!/[0-9]/.test(e.key) || noTextInput.value.length >= 11) {
        e.preventDefault();
    }
});